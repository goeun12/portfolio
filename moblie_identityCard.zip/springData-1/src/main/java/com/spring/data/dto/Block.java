package com.spring.data.dto;

public class Block {
	
	public String hash;
//	public String previousHash; 
	protected String name;
	protected String regNum;	// 주민번호
	protected String address;
//	protected long timeStamp; 
//	protected int nonce;
	
	protected String id;
	protected String pw;
	protected String pinPw;
	 
	// 신분증 생성자
//	public Block(String name, int age, String regNum, String address, String previousHash) {
//		this.name = name;
//		this.age = age;
//		this.regNum = regNum;
//		this.address = address;
//		this.previousHash = previousHash;
//		this.timeStamp = new Date().getTime();
//		
//		this.hash = calculateHash(); 
//	}
	
	public Block() {
		
	}
	
	// Mapper
	public Block(String name, String regNum, String address, String id, String pw, String pinPw) {
		this.name = name;
		this.regNum = regNum;
		this.address = address;
		this.id = id;
		this.pw = pw;
		this.pinPw = pinPw;
	}

	// 해시코드 생성 계산
//	public String calculateHash() {
//		String calculatedhash = StringUtil.applySha256( 
//				previousHash +
//				Long.toString(timeStamp) +
//				Integer.toString(nonce) + 
//				name + Integer.toString(age) + regNum
//				);
//		return calculatedhash;
//	}
	
	// 블록 생성
//	public void mineBlock(int difficulty) {
//		String target = new String(new char[difficulty]).replace('\0', '0');  
//		while(!hash.substring( 0, difficulty).equals(target)) {
//			nonce ++;
//			hash = calculateHash();
//		}
//		System.out.println("Block Mined!!! : " + hash);
//	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRegNum() {
		return regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getPinPw() {
		return pinPw;
	}

	public void setPinPw(String pinPw) {
		this.pinPw = pinPw;
	}
	
	
	
}
