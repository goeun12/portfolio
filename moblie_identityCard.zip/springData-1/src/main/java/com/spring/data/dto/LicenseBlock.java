package com.spring.data.dto;


public class LicenseBlock extends Block {
	private String licenseName;
	private String licenseNum;
	
	// 운전 면허 생성자
//	public LicenseBlock(String name, int age, String regNum, String licenseName, String licenseNum, String previousHash) {
//		this.name = name;
//		this.age = age;
//		this.regNum = regNum;
//		this.previousHash = previousHash;
//		this.timeStamp = new Date().getTime();
//		this.hash = calculateHash();
//		this.licenseName = licenseName;
//		this.licenseNum = licenseNum;
//	}
	
	// Mapper
	public LicenseBlock(String name, String regNum, String licenseNum, String licenseName) {
		this.name = name;
		this.regNum = regNum;
		this.licenseNum = licenseNum;
		this.licenseName = licenseName;
	}
	
//	public String calculateHash() {
//		String calculatedhash = StringUtil.applySha256( 
//				previousHash +
//				Long.toString(timeStamp) +
//				Integer.toString(nonce) + 
//				name + Integer.toString(age) + regNum + licenseName + licenseNum
//				);
//		return calculatedhash;
//	}

	public String getLicenseName() {
		return licenseName;
	}

	public void setLicenseName(String licenseName) {
		this.licenseName = licenseName;
	}

	public String getLicenseNum() {
		return licenseNum;
	}

	public void setLicenseNum(String licenseNum) {
		this.licenseNum = licenseNum;
	}
	
	
}
