package com.spring.data.dto;

public class LoginDTO {
	private String id;
	private String pw;
	private String pinPw;
	private int num;
	
	public LoginDTO(String id, String pw, String pinPw) {
		super();
		this.id = id;
		this.pw = pw;
		this.pinPw = pinPw;
	}

	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getPw() {
		return pw;
	}
	
	public void setPw(String pw) {
		this.pw = pw;
	}
	
	public String getPinPw() {
		return pinPw;
	}
	
	public void setPinPw(String pinPw) {
		this.pinPw = pinPw;
	}
	
	public int getNum() {
		return num;
	}
	
	public void setNum(int num) {
		this.num = num;
	}
	
	

}
