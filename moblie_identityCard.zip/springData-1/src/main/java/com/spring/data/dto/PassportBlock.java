package com.spring.data.dto;

public class PassportBlock extends Block {
	private String nation;
	private String engNation;
	private String passportNum;
	private String end;
	private String engName;
	
	// 여권 생성자
//	public PassportBlock(String name, int age, String regNum, String nation, String passportNum, String previousHash) {
//		this.name = name;
//		this.age = age;
//		this.regNum = regNum;
//		this.previousHash = previousHash;
//		this.timeStamp = new Date().getTime();
//		this.hash = calculateHash();
//		this.nation = nation;
//		this.passportNum = passportNum;
//	}
	
	// Mapper
	public PassportBlock(String nation, String engNation, String name, String engName, String regNum, String passportNum, String end) {
		this.nation = nation;
		this.engNation = engNation;
		this.name = name;
		this.engName = engName;
		this.regNum = regNum;
		this.passportNum = passportNum;
		this.end = end;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getPassportNum() {
		return passportNum;
	}

	public void setPassportNum(String passportNum) {
		this.passportNum = passportNum;
	}

	public String getEngNation() {
		return engNation;
	}

	public void setEngNation(String engNation) {
		this.engNation = engNation;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public String getEngName() {
		return engName;
	}

	public void setEngName(String engName) {
		this.engName = engName;
	}
	
	
	
//	public String calculateHash() {
//		String calculatedhash = StringUtil.applySha256( 
//				previousHash +
//				Long.toString(timeStamp) +
//				Integer.toString(nonce) + 
//				name + Integer.toString(age) + regNum + nation + passportNum
//				);
//		return calculatedhash;
//	}
	
	
}
