package com.spring.data.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.data.dto.Block;
import com.spring.data.dto.HashAdminDTO;
import com.spring.data.dto.LicenseBlock;
import com.spring.data.dto.LoginDTO;
import com.spring.data.dto.PassportBlock;
import com.spring.data.mapper.LoginMapper;

@Service
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	private LoginMapper loginMapper;
	
	
	@Override
	public void insertAdult(Block block) {
		
		loginMapper.insertAdult(block);
	}
	
	@Override
	public void insertLicense(LicenseBlock license) {
		
		loginMapper.insertLicense(license);
	}
	
	@Override
	public void insertPassport(PassportBlock passport) {
		
		loginMapper.insertPassport(passport);
	}
	
	@Override
	public void insertLogin(LoginDTO loginDTO) {
		
		loginMapper.insertLogin(loginDTO);
	}
	
	@Override
	public void insertHashAdmin(HashAdminDTO hashAdminDTO) {
		
		loginMapper.insertHashAdmin(hashAdminDTO);
	}

	
	@Override
	public Integer selectLoginId(String id) {
		
		return loginMapper.selectLoginId(id);
	}
	
	@Override
	public Integer selectLoginPw(String pw) {
		
		return loginMapper.selectLoginPw(pw);
	}
	
	@Override
	public Integer selectForget(String pinPw) {
		
		return loginMapper.selectForget(pinPw);
	}
	
	@Override
	public String selectId(Integer num) {
		
		return loginMapper.selectId(num);
	}
	
	@Override
	public String selectPw(Integer num) {
		
		return loginMapper.selectPw(num);
	}
	
	@Override
	public String selectregNum(String id) {
		
		return loginMapper.selectregNum(id);
	}
	
	@Override
	public String selectFindId(String regNum) {
		
		return loginMapper.selectFindId(regNum);
	}

	@Override
	public Block selectBlockOne(String id) {
		
		return loginMapper.selectBlockOne(id);
	}
	
	@Override
	public LicenseBlock selectLicenseOne(String regNum) {
		
		return loginMapper.selectLicenseOne(regNum);
	}
	
	@Override
	public PassportBlock selectPassportOne(String regNum) {
		
		return loginMapper.selectPassportOne(regNum);
	}
	
	@Override
	public String selectHashPw(String pinPw) {
		
		return loginMapper.selectHashPw(pinPw);
	}
	
	@Override
	public String selectHashPwLogin(String pinPw) {
		
		return loginMapper.selectHashPwLogin(pinPw);
	}



}
