package com.spring.data.configuration;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

// @Configuration: 스프링부트 환경 설정 클래스임을 명시. 자동으로 빈 등록.
// 이 애너테이션이 붙게 되면 @ComponentScan이 스캔할 때 이 클래스에 @Bean으로 지정한 모든 빈들도 IoC 컨테이너에 등록

@Configuration
@PropertySource("classpath:/application.properties")
public class DBConfiguration {
	
	@Autowired
	private ApplicationContext applicationContext;
	
	// HikariCP 설정 1
	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.hikari")
	public HikariConfig hikariConfig() {
		
		return new HikariConfig();
	}
	
	// HikariCP 설정 2
	@Bean
	public DataSource dataSource() {
		
		DataSource dataSource = new HikariDataSource(hikariConfig());
		System.out.println(dataSource.toString());
		
		return dataSource;
	}
	
	// MyBatis 설정 1 : SqlSessionFactory 객체 생성
	@Bean
	public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
		
		SqlSessionFactoryBean factoryBean =	new SqlSessionFactoryBean();
		factoryBean.setDataSource(dataSource);
		factoryBean.setMapperLocations(applicationContext.getResources("classpath:/mapper/LoginMapper.xml"));
		factoryBean.setTypeAliasesPackage("com.spring.data.dto");
		
		return factoryBean.getObject();
	}
	
	// MyBatis 설정 2 : SqlSessionTemplate <- SqlSessionFactory
	@Bean
	public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory) throws Exception {
		
		return new SqlSessionTemplate(sqlSessionFactory);
	}

}
