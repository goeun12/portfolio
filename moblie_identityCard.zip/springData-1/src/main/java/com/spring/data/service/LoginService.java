package com.spring.data.service;

import org.springframework.stereotype.Service;

import com.spring.data.dto.Block;
import com.spring.data.dto.HashAdminDTO;
import com.spring.data.dto.LicenseBlock;
import com.spring.data.dto.LoginDTO;
import com.spring.data.dto.PassportBlock;

@Service
public interface LoginService {
	public void insertAdult(Block block);
	
	public void insertLicense(LicenseBlock license);
	
	public void insertPassport(PassportBlock passport);
	
	public void insertHashAdmin(HashAdminDTO hashAdminDTO);

	public void insertLogin(LoginDTO loginDTO);
	public Integer selectLoginId(String id);
	public Integer selectLoginPw(String pw);
	public Integer selectForget(String pinPw);
	public String selectId(Integer num);
	public String selectPw(Integer num);
	
	public String selectregNum(String id);
	public String selectFindId(String regNum);
	public Block selectBlockOne(String id);
	public LicenseBlock selectLicenseOne(String regNum);
	public PassportBlock selectPassportOne(String regNum);
	public String selectHashPw(String pinPw);
	public String selectHashPwLogin(String pinPw);


}
