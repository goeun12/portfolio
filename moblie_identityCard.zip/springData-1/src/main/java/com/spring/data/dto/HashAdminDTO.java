package com.spring.data.dto;

public class HashAdminDTO {
	
	private String regNum;
	private String pinPw;
	private String hashPw;
	
	public HashAdminDTO(String regNum, String pinPw) {
		super();
		this.regNum = regNum;
		this.pinPw = pinPw;
	}

	public String getRegNum() {
		return regNum;
	}
	
	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}
	
	public String getPinPw() {
		return pinPw;
	}
	
	public void setPinPw(String pinPw) {
		this.pinPw = pinPw;
	}
	
	public String getHashPw() {
		return hashPw;
	}
	
	public void setHashPw(String hashPw) {
		this.hashPw = hashPw;
	}
	
	

}
