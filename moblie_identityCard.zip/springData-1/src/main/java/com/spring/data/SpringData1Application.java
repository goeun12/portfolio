package com.spring.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringData1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringData1Application.class, args);
	}

}
