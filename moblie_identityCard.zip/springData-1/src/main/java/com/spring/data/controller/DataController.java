package com.spring.data.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.data.dto.Block;
import com.spring.data.dto.HashAdminDTO;
import com.spring.data.dto.LicenseBlock;
import com.spring.data.dto.LoginDTO;
import com.spring.data.dto.PassportBlock;
import com.spring.data.service.LoginService;

@Controller
public class DataController {
	
	@Autowired
	private LoginService loginService;
	
	// 첫 화면
	@GetMapping("/")
	public String loading() {
		
		return "/login/loginForm";
	}
	
	
	// 로그인 페이지
	@GetMapping("/login/loginForm")
	public String loginForm(
			@RequestParam(value="num", required=false) Integer num,
			Model model) {
		
		if(num != null) {
			String id = loginService.selectId(num);
			String pw = loginService.selectPw(num);
			
			model.addAttribute("id", id);
			model.addAttribute("pw", pw);
		}
		
		return "/login/loginForm";
	}
	
	
	// 회원 가입 페이지
	@GetMapping("/login/joinForm")
	public String joinForm() {
		
		return "/login/joinForm";
	}
	
	
	// 아이디, 비밀번호 찾기 페이지
	@GetMapping("/login/forgetForm")
	public String forgetForm() {
		
		return "/login/forgetForm";
	}
	
	
	// 회원 가입 완료 페이지
	@PostMapping("/login/joinuser")
	public String joinUser(
			@RequestParam(value="name") String name,
			@RequestParam(value="regNum") String regNum,
			@RequestParam(value="id") String id,
			@RequestParam(value="pw") String pw,
			@RequestParam(value="pwCheck") String pwCheck,
			Model model) {
		
		try {
			
			Integer num = loginService.selectLoginId(id);

			if((name == "") || (regNum == "") || (id == "") || (pw == "") || (pwCheck == "")) {
				model.addAttribute("msg", "회원 가입에 필요한 정보가 없습니다. 다시 시도하세요.");
				model.addAttribute("url", "/login/joinForm");
				
				return "/login/messageAlert";
				
			} else if(!(pw.equals(pwCheck))) {
				model.addAttribute("msg", "비밀번호 확인이 올바르지 않습니다. 다시 시도하세요.");
				model.addAttribute("url", "/login/joinForm");
				
				return "/login/messageAlert";
			} else if(num != null) {
				model.addAttribute("msg", "이미 존재하는 아이디입니다. 다시 시도하세요.");
				model.addAttribute("url", "/login/joinForm");
			
				return "/login/messageAlert";
			}
		
			String address = "서울 광진구";
			String pinPw = regNum.substring(6, regNum.length());
			String regNum_ = regNum.subSequence(0, 6) + "-" + regNum.substring(6, regNum.length());
			
			String licenseName = "2종 보통";
			String licenseNum = "01-23-456789-01";
			
			String engName = "English Name";
			String nation = "대한민국";
			String engNation = "Republic of Korea";
			String passportNum = "M123A4567";
			String end = "2025-11-17";
			
			Block b = new Block(name, regNum_, address, id, pw, pinPw);
			LoginDTO login = new LoginDTO(id, pw, pinPw);
			HashAdminDTO h = new HashAdminDTO(regNum, pinPw);

			loginService.insertAdult(b);
			loginService.insertLogin(login);
			loginService.insertHashAdmin(h);
			
			if(licenseName != "no") {
				LicenseBlock l = new LicenseBlock(name, regNum_, licenseNum, licenseName);
				loginService.insertLicense(l);
			}
			
			PassportBlock p = new PassportBlock(nation, engNation, name, engName, regNum_, passportNum, end);
			loginService.insertPassport(p);
			
			Integer ok = loginService.selectLoginId(id);
		
			model.addAttribute("msg", "회원가입이 완료되었습니다. 로그인을 시도하세요.");
			model.addAttribute("url", "/login/loginForm?num=" + ok);
		
			return "/login/messageAlert";
		
		} catch(Exception e) {
			
		}
		
		model.addAttribute("msg", "회원가입을 한 사용자입니다. 로그인을 시도하세요.");
		model.addAttribute("url", "/login/loginForm");
	
		return "/login/messageAlert";
	}
	
	// 로그인 완료 페이지
	@PostMapping("/login/loginuser")
	public String loginUser(
			@RequestParam(value="id") String id,
			@RequestParam(value="pw") String pw,
			Model model) {
		
		Integer idNum = loginService.selectLoginId(id);
		Integer pwNum = loginService.selectLoginPw(pw);
		
		
		System.out.println(idNum);
		System.out.println(pwNum);
		
		if((idNum == null) || (pwNum == null)) {
			
			model.addAttribute("msg", "유효한 정보가 없습니다. 다시 시도하세요.");
			model.addAttribute("url", "/login/loginForm");
		
			return "/login/messageAlert";
		
		}else if(idNum == pwNum) {
			model.addAttribute("msg", "로그인이 완료되었습니다.");
			model.addAttribute("url", "/selecttype?num=" + idNum);
		
			return "/login/messageAlert";
		} else {
			model.addAttribute("msg", "로그인에 실패하였습니다. 다시 시도하세요.");
			model.addAttribute("url", "/login/loginForm");
		
			return "/login/messageAlert";
		}
		
	}
	
	
	// 아이디, 비밀번호 찾기 페이지
	@PostMapping("/login/forgetuser")
	public String forgetUser(
			@RequestParam(value="pinPw") String pinPw,
			Model model) {
		
		// 핀번호를 이용해서 login 테이블의 num 값을 찾고,
		// num 값에 있는 id와 pw를 다시 찾은 뒤,
		// messageAlert로 보여주기
		// return은 로그인 페이지, 뒤에 ?num = num 만들기
		// loginForm() 수정, -> memberConrtoller 보기
		try {
		Integer pinPwNum = loginService.selectForget(pinPw);

		System.out.println(pinPwNum);
		
		if(pinPwNum == null) {
			model.addAttribute("msg", "회원 정보가 없습니다. 회원가입을 하세요.");
			model.addAttribute("url", "/login/joinForm");
			
			return "/login/messageAlert";
		}
		
		String id = loginService.selectId(pinPwNum);
		String pw = loginService.selectPw(pinPwNum);
		
		System.out.println(id);
		System.out.println(pw);
		
		model.addAttribute("msg", "회원님의 아이디는 \"" + id + "\"이고, 비밀번호는 \"" + pw + "\" 입니다.");
		model.addAttribute("url", "/login/loginForm?num=" + pinPwNum);
		
		return "/login/messageAlert";
		
		} catch(Exception e){
			
		}
		
		return "/login/messageAlert";
	}
	
	
	// 버튼 선택
	@GetMapping("/selecttype")
	public String selectType(
			@RequestParam(value="num", required=false) Integer num,
			Model model) {
		
		model.addAttribute("num", num);
		System.out.println(num);
		
		model.addAttribute("adult", "adult");
		model.addAttribute("license", "license");
		model.addAttribute("passport", "passport");
		
		return "/button/buttonForm";
	}
	
	// 핀패드에 잇는 번호 받기
		@PostMapping("/numberpass/ok")
		public String numPass(
				@RequestParam(value="num", required=false) Integer num,
				@RequestParam(value="adult", required=false) String adult,
				@RequestParam(value="license", required=false) String license,
				@RequestParam(value="passport", required=false) String passport,
				Model model) {
			
			System.out.println(num);
			System.out.println(adult);
			System.out.println(license);
			System.out.println(passport);
			
			if(adult != null) {
				
				model.addAttribute("url", "/pinpad/check?num=" + num + "&type=" + adult);
			} else if(license != null) {
				
				model.addAttribute("url", "/pinpad/check?num=" + num + "&type=" + license);

			} else if(passport != null) {
				
				model.addAttribute("url", "/pinpad/check?num=" + num + "&type=" + passport);
			}
			
			return "/login/messageUrl";
		}
		
	// 로그아웃
	@GetMapping("/logout")
	public String logout(
			Model model) {
		
		model.addAttribute("msg", "로그아웃합니다.");
		model.addAttribute("url", "/login/loginForm");
		
		return "/login/messageAlert";
		
	}
	
	
	// 핀패드 확인
	@GetMapping("/pinpad/check")
	public String pinPad(
			@RequestParam(value="num", required=false) Integer num,
			@RequestParam(value="type", required=false) String type,
			Model model) {
		
		model.addAttribute("num", num);
		model.addAttribute("type", type);
		model.addAttribute("submit", "submit");
		model.addAttribute("back", "back");
		
		return "/pinpad/pinpadForm";
	}
	
	
	// 핀패드 입력하면 나오는 페이지
	@PostMapping("/pinpad/pinpaduser")
	public String pinpadUser(
			@RequestParam(value="num", required=false) Integer num,
			@RequestParam(value="type", required=false) String type,
			@RequestParam(value="pinPw", required=false) String pinPw,
			@RequestParam(value="submit", required=false) String submit,
			Model model) {
		
		System.out.println(num);
		System.out.println(type);
		System.out.println(pinPw);
		
		// pinPw와 HashPw 비교해서 일치하면 통과
		// pinPw는 그대로 두고, HashPw만 만들기
		String hashPw = loginService.selectHashPw(pinPw);
		System.out.println(hashPw);
		
		String loginHashPw = loginService.selectHashPwLogin(pinPw);
		System.out.println(loginHashPw);
		
		if(submit != null) {
			if(loginHashPw.equals(hashPw)) {

				model.addAttribute("msg", "비밀번호가 일치합니다.");
			
				if(type.equals("adult")) {
					model.addAttribute("url", "/show/identificationPage?num=" + num + "&type=" + type);
			
				} else if(type.equals("license")) {
					model.addAttribute("url", "/show/licensePage?num=" + num + "&type=" + type);

				} else if(type.equals("passport")){
					model.addAttribute("url", "/show/passportPage?num=" + num + "&type=" + type);
				}
			
				return "/login/messageAlert";
			
			} else {
			
				model.addAttribute("msg", "비밀번호가 일치하지 않습니다. 다시 시도하세요.");
				model.addAttribute("url", "/pinpad/check?num= " + num + "&type=" + type);
			
			
				return "/login/messageAlert";
			}
		} else{
			model.addAttribute("url",  "/selecttype?num=" + num);
			
			return "/login/messageUrl";
		}

	}
	
	// 신분증 보여주는 화면
	@GetMapping("/show/identificationPage")
	public String showAdult(
			@RequestParam(value="num", required=false) Integer num,
			@RequestParam(value="type", required=false) String type,
			Model model) {
		
		String id = loginService.selectId(num);
		Block b = loginService.selectBlockOne(id);
		
		model.addAttribute("Block", b);
		
		return "/show/show_adult";
	}
	
	// 신분증 화면에서 처음으로 버튼
	@PostMapping("/show/identificationPageok")
	public String identificationBack(
			@RequestParam(value="name", required=false) String name,
			@RequestParam(value="regNum", required=false) String regNum,
			@RequestParam(value="address", required=false) String address,
			@RequestParam(value="id", required=false) String id,
			@RequestParam(value="pw", required=false) String pw,
			@RequestParam(value="pinPw", required=false) String pinPw,
			Model model) {
		
		Integer num = loginService.selectForget(pinPw);
		
		model.addAttribute("url",  "/selecttype?num=" + num);
		
		return "/login/messageUrl";
		
	}
	
	// 면허 보여주는 화면
	@GetMapping("/show/licensePage")
	public String showLicense(
			@RequestParam(value="num", required=false) Integer num,
			@RequestParam(value="type", required=false) String type,
			Model model) {
		
		String id = loginService.selectId(num);
		String regNum = loginService.selectregNum(id);
		LicenseBlock l = loginService.selectLicenseOne(regNum);
		
		model.addAttribute("LicenseBlock", l);
		
		return "/show/show_license";
	}
	
	// 면허 화면에서 처음으로 버튼
	@PostMapping("/show/licensePageok")
	public String licenseBack(
			@RequestParam(value="name", required=false) String name,
			@RequestParam(value="regNum", required=false) String regNum,
			@RequestParam(value="address", required=false) String address,
			Model model) {
			
		// regNum -> id 찾기 // id -> num 찾기
		
		String id = loginService.selectFindId(regNum);
		
		Integer num = loginService.selectLoginId(id);
		
		model.addAttribute("url",  "/selecttype?num=" + num);
			
		return "/login/messageUrl";
			
	}
	
	// 여권 보여주는 화면
	@GetMapping("/show/passportPage")
	public String showPassport(
			@RequestParam(value="num", required=false) Integer num,
			@RequestParam(value="type", required=false) String type,
			Model model) {
		
		String id = loginService.selectId(num);
		String regNum = loginService.selectregNum(id);
		System.out.println(regNum);
		PassportBlock p = loginService.selectPassportOne(regNum);
		
		model.addAttribute("PassportBlock", p);
		
		return "/show/show_passport";
	}
	
	// 여권 화면에서 처음으로 버튼
	@PostMapping("/show/passportPageok")
	public String passportBack(
			@RequestParam(value="nation", required=false) String nation,
			@RequestParam(value="engNation", required=false) String engNation,
			@RequestParam(value="name", required=false) String name,
			@RequestParam(value="engName", required=false) String engName,
			@RequestParam(value="regNum", required=false) String regNum,
			@RequestParam(value="passportNum", required=false) String passportNum,
			@RequestParam(value="end", required=false) String end,
			Model model) {
			
		// regNum -> id 찾기 // id -> num 찾기
		
		String id = loginService.selectFindId(regNum);
		
		Integer num = loginService.selectLoginId(id);
		
		model.addAttribute("url",  "/selecttype?num=" + num);
			
		return "/login/messageUrl";
			
	}
	
	

}
