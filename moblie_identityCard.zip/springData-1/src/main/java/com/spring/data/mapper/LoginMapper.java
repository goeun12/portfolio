package com.spring.data.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.spring.data.dto.Block;
import com.spring.data.dto.HashAdminDTO;
import com.spring.data.dto.LicenseBlock;
import com.spring.data.dto.LoginDTO;
import com.spring.data.dto.PassportBlock;

@Mapper
public interface LoginMapper {
	// 회원가입할 때
	public void insertAdult(Block block);
	public void insertLicense(LicenseBlock license);
	public void insertPassport(PassportBlock passport);
	public void insertHashAdmin(HashAdminDTO hashAdminDTO);
	
	// 로그인 입력할 때
	public void insertLogin(LoginDTO loginDTO);
	public Integer selectLoginId(String id);
	public Integer selectLoginPw(String pw);
	
	public Integer selectForget(String pinPw);
	
	// 아이디, 비밀번호 갔다 넣기(로그인에 사용)
	public String selectId(Integer num);
	public String selectPw(Integer num);
	
	// 운전면허, 여권 보여주려면 regNum을 받아와야함
	public String selectregNum(String id);
		
	// regNum으로 id를 찾아와야함
	public String selectFindId(String regNum);
		
	// 개인정보 보여줄 때
	public Block selectBlockOne(String id);
	public LicenseBlock selectLicenseOne(String regNum);
	public PassportBlock selectPassportOne(String regNum);
	
	// hahsPw 뽑기 
		// 정부
	public String selectHashPw(String pinPw);
		// 개인
	public String selectHashPwLogin(String pinPw);

}
